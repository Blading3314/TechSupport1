import java.util.*;
/**
 * The responder class represents a response generator object.
 * It is used to generate an automatic response to an input string.
 * 
 * @author     Michael Kölling and David J. Barnes
 * @version    0.1 (2016.02.29)
 */
public class Responder
{
    private Random random_generator;
    private ArrayList<String> responses;
    private HashMap <String, String> responseMap;
   
    /**
     * Construct a Responder - nothing to do
     */
    public Responder()
    {
     random_generator = new Random();
     responses = new ArrayList<>(); 
     responseMap = new HashMap<>(); 
    
     fillResponses();
     fillResponsesMap(); 

    }
    //43
    private void fillResponsesMap(){
        responseMap.put("slow", "Try restarting your computer.");
        responseMap.put("crash", "Check for software updates.");
        responseMap.put("error", "What error message are you seeing?");
        responseMap.put("network", "Try reconnecting to your Wi-Fi.");
    }
    /*34. Use HashSet when uniqueness is needed, 
    and use ArrayList when maintaining order is required. */
    /* 37.
     * ArrayList: Maintains insertion order, allows duplicates.
     * HashSet: Removes duplicates, unordered.
     */
    //38. If a string contains multiple spaces, it will create empty elements.
    public void fillResponses(){ //22
        responses.add("yes");
        responses.add("no");
        responses.add("Who knows?");
        responses.add("Probably");
        responses.add("Maybe");
        responses.add("No idea");
    }
    /**
     * Generate a response.
     * @return   A string that should be displayed as the response
     */ //27
    public String generateResponse()
    {
        int index = random_generator.nextInt(responses.size()); 
        return responses.get(index);
    
    }
    private String pickDefaultResponse(){
        return "no idea, sorry"; 
    }
    //42
    public String generateResponse(HashSet<String> words)
    { 
             for (String word : words) {
            if (responseMap.containsKey(word)) {
                return responseMap.get(word);
            }
        }
        return pickDefaultResponse();
}
}

 /*39. 
  * Arrays.sort(array): Sorts an array.
  * Arrays.fill(array, value): Fills an array with a value.
  */
 /*40. 
  * Arrays.toString(array): Converts an array to a string representation.
  * 
  */
 