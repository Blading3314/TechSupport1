import java.util.Arrays;
/**
 * Write a description of class SortingTest here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
/**
 * Question 41
 */
public class SortingTest
{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class SortingTest
     */
    public void Sort(int [] array)
    {
        // initialise instance variables
        Arrays.sort(array); 
        System.out.println(Arrays.toString(array)); 
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public void sortNumbers()
    {
        // put your code here
        SortingTest test = new SortingTest();
        int[] numbers = {5, 2, 8, 1, 3};
        test.Sort(numbers);
    }
}
